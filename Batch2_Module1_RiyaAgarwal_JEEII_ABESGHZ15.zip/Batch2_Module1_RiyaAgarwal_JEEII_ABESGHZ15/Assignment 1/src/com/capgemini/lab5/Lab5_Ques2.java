package com.capgemini.lab5;
import java.util.Scanner;

public class Lab5_Ques2 {
	
	public static int fibonacci(int n) {
		int n1=1;
		int n2=1;
		int ar[]=new int[num];
		arr[0]=n1;
		arr[1]=n2;
		int i=2,temp=0;
		while(i<n) {
			temp=n1+n2;
			arr[i]=temp;
			n1=n2;
			n2=temp;
			i++;
		}
		return arr[n-1];
	}
	
	public static int recursiveFibonacci(int n) {
		if(n==0) 
		{
			return 0;
		}
		else if(n==1) 
		{
			return 1;
		}
		else 
		{
			return (recursiveFibonacci(n-1)+recursiveFibonacci(n-2));
		}
	}
	public static void main(String args[]) {
		
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		int input=sc.nextInt();
		System.out.println(fibonacci(input));
		System.out.println(recursiveFibonacci(input));
	}



}
