package com.capgemini.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ques3 {
	Scanner sc=new Scanner(System.in);
	int size=sc.nextInt();
	int array[]=new int[size];
	void getValues() {
	for(int i=0;i<size;i++)
	{
		array[i]=sc.nextInt();
	}
	}
	int findSmallest()
	{
		Arrays.sort(array);
		return array[1];
	}
	public static void main(String[] args) {
		Lab3_Ques3 obj=new Lab3_Ques3();
		obj.getValues();
		System.out.println(obj.findSmallest());


	}

}
