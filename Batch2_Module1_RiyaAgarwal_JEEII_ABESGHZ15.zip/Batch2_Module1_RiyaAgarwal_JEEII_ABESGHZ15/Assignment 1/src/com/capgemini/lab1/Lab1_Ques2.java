package com.capgemini.lab1;

import java.util.Scanner;

public class Lab1_Ques2 {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of n: ");
		int n=sc.nextInt();
		int sum=Lab1_Ques2.calDifference(n);
		System.out.println("Difference: "+sum);
	}
	public static int calDifference(int n) {
		int sum,a=0,b=0;
		for(int i=1;i<=n;++i) {
			a=a+i;
			b+=Math.pow(i,2);
		}
		return sum=(int) (Math.pow(a, 2)-b);
	}

}
