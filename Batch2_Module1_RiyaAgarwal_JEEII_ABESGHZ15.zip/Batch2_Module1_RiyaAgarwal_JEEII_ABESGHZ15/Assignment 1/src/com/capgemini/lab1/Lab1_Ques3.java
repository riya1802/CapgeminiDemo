package com.capgemini.lab1;

import java.util.Scanner;

public class Lab1_Ques3 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number n= ");
        int n = scanner.nextInt();
        int previousDigit = 9;
        boolean increasingNumber = true;
        while (n > 0) {
            int PresentDigit = n % 10;
            n = n / 10;
            if (PresentDigit > previousDigit) {
                increasingNumber = false;
                break;
            }
            previousDigit = PresentDigit;
        }
        System.out.println("Increasing number = " + increasingNumber);
    }

}
