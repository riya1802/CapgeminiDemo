package com.capgemini.lab1;

import java.util.Scanner;

public class Lab1_Ques1 
{
		public static void main(String[]args)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number= ");
		int n=sc.nextInt();
		int sum=Lab1_Ques1.calSum(n);
		System.out.println("Sum of first n numbers divisible by 3 or 5 : "+sum);
		}
		public static int calSum(int n)
		{
			int sum=0;
			for(int i=1;i<=n;i++) {
				if((i%3==0) || (i%5==0))
				{
					sum=sum+i;
				}
			}
			return sum;
		}
	}