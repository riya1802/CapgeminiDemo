package com.capgemini.lab1;

import java.util.Scanner;

public class Lab1_Ques4 {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int a=sc.nextInt();
		boolean check=Lab1_Ques4.check(a);
	    if(check)
		    System.out.println(a+" is a power of 2");
	    else
	    	System.out.println(a+" is not a power of 2");
	}
	public static boolean check(int a) {
		int b=(int) Math.pow(2, Math.round(Math.log(a)/Math.log(2)));
	    if(b==a)
	    	return true;
	    else
	    	return false;

}
}