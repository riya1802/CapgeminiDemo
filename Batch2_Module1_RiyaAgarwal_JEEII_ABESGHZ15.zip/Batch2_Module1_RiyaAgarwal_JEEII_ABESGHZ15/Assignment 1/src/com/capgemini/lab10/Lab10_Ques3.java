package com.capgemini.lab10;

@FunctionalInterface
interface Accept{

	public boolean check(String usernam,String password);
}
public class Lab10_Ques3 {

	public static void main(String[]args) {
		String name="Riya Agawal";
		String pass="riya";
		Accept a=(s1,s2)->{
			if(s1.equals("Riya Agarwal") && s2.equals("riya"));
			return true;
		};
		System.out.println(a.check(name,pass));
	}
}
