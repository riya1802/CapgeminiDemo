package com.capgemini.lab10;
interface Lab10_2{
	public String space(String str) ;
	public String modify(String str);

}

public class Lab10_Ques2 {
		public static void main(String[] args) {
			
		
				String str="ABES";
				Lab10_2 f1=(a)->
				{
					String z="";
					for(int i=0;i<s.length();i++) {
						char x=s.charAt(i);
						z+=x+" ";
					}
					z.trim();
					return z;
				};
				System.out.println(f1.modify(str));
			}
}
