package com.capgemini.lab10;
@FunctionalInterface
interface Lab10 {

	public double power(int a,int b);
}
public class LambdaExpression {
	public static void main(String[]args) {
		Lab10 c1=(a,b) -> Math.pow(a,b);
		System.out.println(c1.power(3, 3));
	}
}
