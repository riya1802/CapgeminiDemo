package com.capgemini.lab6;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Lab6_Ques1 {
		    public static void main(String args[]) {
		        int n;
		        int sum=0;
		        Scanner sc = new Scanner(System.in);
		        System.out.println("Enter the line = ");
		        String str=sc.nextLine();
		        StringTokenizer a=new StringTokenizer(str, " ");
		        System.out.println("Integers: ");
		        while (a.hasMoreTokens()) {
		            String s=a.nextToken();
		            n=Integer.parseInt(s);
		            System.out.println(n);
		            sum=sum+n;
		        }
		        System.out.println("sum of integers is: "+sum);
		    }
}
