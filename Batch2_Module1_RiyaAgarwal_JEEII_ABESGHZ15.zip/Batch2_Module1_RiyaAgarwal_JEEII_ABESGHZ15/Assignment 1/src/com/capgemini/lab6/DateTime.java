package com.capgemini.lab6;
import java.io.*;
import java.util.*;
class DateTime
{
public static void main(String args[])
{
File f=new File(args[0]);
System.out.println("name :"+f.getName());
System.out.println("path:"+f.getAbsolutePath());
System.out.println("exists:"+f.exists());
System.out.println("is file:"+f.isFile());
System.out.println("is dir:"+f.isDirectory());
System.out.println("read :"+f.canRead());
System.out.println("write:"+f.canWrite());

long l=f.lastModified();
DateTime d=new DateTime();
int date=d.getDate();
int month=d.getMonth();
int year=d.getYear();
int hh=d.getHours();
int mm=d.getMinutes();
int ss=d.getSeconds();
System.out.println(date+"/"+(month+1)+"/"+(1900+year));
System.out.println(hh+":"+mm+":"+ss);
}

private int getSeconds() {
	// TODO Auto-generated method stub
	return 0;
}

private int getMinutes() {
	// TODO Auto-generated method stub
	return 0;
}

private int getHours() {
	// TODO Auto-generated method stub
	return 0;
}

private int getYear() {
	// TODO Auto-generated method stub
	return 0;
}

private int getDate() {
	// TODO Auto-generated method stub
	return 0;
}

private int getMonth() {
	// TODO Auto-generated method stub
	return 0;
} 
}