package com.capgemini.lab6;
import java.util.Date;


class TimerDisplayex implements Runnable {

	public void run() 
	{
		for( ;  ;  ) {
			try {
				Date d = new Date();
				System.out.println(d);
				Thread.sleep(10000);
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public class Lab6_TimerDisplay {

		public static void main(String[] args) {

			TimerDisplayex td = new TimerDisplayex();
			Thread t = new Thread(td);
			t.start();
		}
	}