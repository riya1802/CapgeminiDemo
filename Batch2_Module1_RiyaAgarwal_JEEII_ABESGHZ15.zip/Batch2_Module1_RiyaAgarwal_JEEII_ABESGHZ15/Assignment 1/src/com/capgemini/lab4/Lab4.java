package com.capgemini.lab4;

import java.util.Scanner;

public class Lab4{
	public static int getCube(int n){
		int cube=0;
		while(n>0){
			int temp=n%10;
			cube+=(temp*temp*temp);
			n=n/10;	
			}
		return cube;
		}
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number= ");
		int a=sc.nextInt();
		System.out.println(getCube(a));
		sc.close();
	}

}
