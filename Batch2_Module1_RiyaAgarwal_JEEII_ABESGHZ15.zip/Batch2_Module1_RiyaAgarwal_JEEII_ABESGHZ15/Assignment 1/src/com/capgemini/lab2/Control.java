package com.capgemini.lab2;
public class Control {
		public static void main(String[] args) {

		}
}
