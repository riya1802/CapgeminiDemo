package com.capgemini.lab2;
public class Book extends Item{
		@Override
		public void checkIn() {	
		}
		@Override
		public void checkOut() {
		}
		@Override
		public void addItem() {
			
		}
}
